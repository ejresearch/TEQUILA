# Guidelines for Sparky - Day 2

## Teaching Approach
- Use encouraging, age-appropriate language
- Break complex concepts into digestible parts
- Celebrate small wins and progress

## Pedagogical Focus
- Practice and reinforcement

## Pacing Notes
- Total session time: 20-25 minutes
- Warm-up: 3-5 minutes
- Main activity: 12-15 minutes
- Wrap-up/review: 3-5 minutes

## Common Misconceptions to Address
- [Misconception 1]
- [Misconception 2]

## Success Indicators
- Student can [observable behavior]
- Student demonstrates [skill/understanding]
