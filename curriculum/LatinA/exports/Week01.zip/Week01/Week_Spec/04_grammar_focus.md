# Grammar Focus - Week 1

## Primary Grammar Concept
[Main grammar concept for the week]

## Teaching Sequence
1. Introduction
2. Guided practice
3. Independent application

## Examples
- Example 1
- Example 2
- Example 3

## Common Errors to Address
- Error pattern 1
- Error pattern 2
