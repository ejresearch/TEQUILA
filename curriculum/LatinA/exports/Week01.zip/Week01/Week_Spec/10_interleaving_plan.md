### Teacher Notes

- **Pronunciation Cues**: Emphasize the hard sounds of 'C' and 'G'.
- **Pacing Advice**: Spend the first two days focusing on vowels, then move to consonants.
- **Connection to Prior/Next Weeks**: This week sets the foundation for reading and speaking. Next week, we'll build on these sounds with simple words.
- **Encouragement**: Remind students that discipline in practice leads to mastery.