### Teacher Notes

- **Pronunciation Tips:** Emphasize the clear pronunciation of vowels. Use examples from English to help students relate.
- **Pacing Advice:** Spend the first two days focusing on the alphabet and pronunciation. Use chants to reinforce learning.
- **Connections:** This week sets the foundation for understanding Latin sounds, which will be crucial as we move into more complex grammar and vocabulary in the coming weeks.
- **Encouragement:** Remind students that discipline in practice will lead to mastery and confidence in their Latin studies.