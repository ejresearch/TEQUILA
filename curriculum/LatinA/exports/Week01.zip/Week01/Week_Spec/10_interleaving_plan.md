### Teacher Notes

- **Pronunciation Tips**: Emphasize the differences in vowel sounds between Latin and English. Use clear examples to demonstrate.
- **Pacing Advice**: Spend time each day practicing the alphabet chant. Encourage students to practice at home.
- **Connections**: This week sets the stage for understanding Latin sounds, which will be crucial in upcoming lessons on vocabulary and grammar.