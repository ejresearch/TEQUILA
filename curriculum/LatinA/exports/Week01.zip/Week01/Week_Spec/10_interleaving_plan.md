### Teacher Notes

- **Pronunciation Cues**: Emphasize the hard sounds of 'C' and 'G'.
- **Pacing Advice**: Spend time each day on pronunciation drills. Use the chant to reinforce memory.
- **Connections**: This week lays the groundwork for reading Latin. Next week, we'll build on this by introducing simple words.
- **Encouragement**: Remind students that discipline in practice leads to mastery.