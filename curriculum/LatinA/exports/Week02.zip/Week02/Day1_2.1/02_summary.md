---
week: 2
day: 1
license: 'CC BY 4.0'
validated_by: Steel
originality_attestation: true
---

# Week 0 Day 1: Introduction to Latin Nouns and First Declension

## Objective
Today, students will be introduced to Latin nouns and the first declension, focusing on understanding and memorizing the noun endings.

## Prior Knowledge
- Familiarity with basic Latin vocabulary such as "puella" (girl) and "aqua" (water).
- Understanding of simple Latin greetings like "salve" (hello).

## Focus for Today
- Grammar: Introduction to the first declension of Latin nouns, emphasizing the nominative and accusative cases.
- Chant: A rhythmic chant to help memorize the first declension endings.
- Vocabulary: 
  - puella (girl)
  - aqua (water)
  - terra (earth)
  - femina (woman)
  - nauta (sailor)
  - poeta (poet)

## Virtue & Faith Connection
Today's study of Latin nouns connects to the virtue of diligence, as students diligently memorize declension endings. The faith phrase "Deus est" (God is) reminds us of the constancy and order in language and life.

## Teacher Notes
Encourage students to chant the declension endings together to reinforce memory. Remind them to pronounce each vowel clearly, as Latin pronunciation relies on distinct vowel sounds. Pace the lesson to allow time for repetition and practice.