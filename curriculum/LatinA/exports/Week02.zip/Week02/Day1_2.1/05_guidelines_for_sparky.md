```markdown
---
week: 1
day: 1
title: "Week 1 Day 1"
time_window_minutes: 20
tone: "warm-positive-brief"
audience: "Grade 3 (Grammar Stage, U.S.)"
license: "CC BY 4.0"
provenance:
  generator: "Steel"
  prompt_id: "prompt_for_guidelines"
  version: "1.0.0"
  generated_at: "2023-10-10T10:00:00Z"
---

# Week 1 Day 1: Week 1 Day 1

## Objectives & Success Criteria
### Objectives
- Students will learn basic Latin greetings and simple phrases.
- Students will practice pronunciation using ecclesiastical Latin.
- Students will recognize and use simple Latin vocabulary in greetings.

### Success Criteria
- Students can greet each other using 'salve' and 'vale'.
- Students pronounce Latin words correctly.
- Students use 'Pax vobiscum' appropriately.
- Students show respect through language use.

## Materials & Setup
- Chant chart (from WeekSpec)
- Flashcards (salve, vale, pax, amica, amicus)
- Parsing worksheet (simple noun cases)
- Visual aids for pronunciation

## Minute-by-Minute Flow

### Phase 1: Greeting & Spiral Review (5 min)
**Sparky says:**
"Salvē, discipuli! Today we'll practice **Respect** as we greet each other in Latin."

**Activity:**
- Show flashcards: "Salve", "Vale", "Pax"
- Ask: "What does 'salve' mean?" (Hint: It's how we say hello!)
- Recycle: "Remember, 'vale' is for goodbye."

**Check for Understanding:**
- "What does 'salve' mean?"

---

### Phase 2: Chant Introduction/Practice (5–7 min)
**Sparky says:**
"Let's say 'Salve, discipuli!' with a smile! We'll chant it once slowly, then with rhythm."

**Activity:**
- Display chant chart
- Model chant: "Salve, discipuli! Vale, amici! Pax vobiscum."
- Students echo
- Point to words as they chant

**Check for Understanding:**
- "How do you say goodbye in Latin?"

---

### Phase 3: Grammar Instruction (8–10 min)
**Focus:** Introduction to basic greetings

**Sparky says:**
"Which word do we use to greet a friend?"

**Activity:**
- Introduce basic greeting structure
- Show example: "Salve, amica!"
- Parse together: "Amica" (nominative, singular)
- Highlight misconception: Mixing 'salve' and 'vale'
  - Correction: "Remember, 'salve' is for hello, 'vale' is for goodbye."

**Check for Understanding:**
- "Can you greet a friend in Latin?"

---

### Phase 4: Guided Practice (5–7 min)
**Sparky says:**
"Try greeting your partner using 'Salve, amicus!'"

**Activity:**
- Present practice sentences: "Salve, amica!", "Vale, discipule!"
- Students practice with partners
- Differentiation:
  - **Support:** Use visual aids for pronunciation
  - **Extension:** Form simple sentences with greetings

**Check for Understanding:**
- "What does 'Pax vobiscum' mean?"

---

### Phase 5: Closure & Virtue Tie-In (2–3 min)
**Sparky says:**
"Use greetings to show respect and kindness to classmates."

**Faith Integration:**
"Use 'Pax vobiscum' when greeting or parting to wish peace."

**Activity:**
- Review objectives
- Students self-assess: "Did I greet my friend correctly?"
- Close with: "Pax vobiscum."

---

## Coaching Notes
### Common Misconceptions
- **Pattern:** Mixing 'salve' and 'vale'
  **Correction Cue:** "Remember, 'salve' is for hello, 'vale' is for goodbye."

### Differentiation Strategies
- **Support:** Provide pronunciation guides, use visual aids for vocabulary
- **Extension:** Challenge students to form simple sentences, encourage role-play using greetings

### Classroom Management
- Keep transitions smooth with chants
- Encourage participation with positive feedback

---

## Assessment Checkpoints
Embedded in flow above:
- Phase 1: "What does 'salve' mean?"
- Phase 2: "How do you say goodbye in Latin?"
- Phase 3: "Can you greet a friend in Latin?"
- Phase 4: "What does 'Pax vobiscum' mean?"
- Phase 5: Self-assessment against success criteria
```