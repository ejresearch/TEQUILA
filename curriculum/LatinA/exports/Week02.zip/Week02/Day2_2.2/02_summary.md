---
week: 2
day: 2
license: 'CC BY 4.0'
validated_by: Steel
originality_attestation: true
---

# Week 0 Day 2: Introduction to First Declension Nouns

## Objective
Today, students will learn to identify and use the first declension noun endings in Latin, focusing on their forms and functions in sentences.

## Prior Knowledge
- Students have previously been introduced to basic Latin vocabulary such as "puella" (girl) and "aqua" (water).
- They have practiced simple Latin greetings like "salve" (hello) and "vale" (goodbye).

## Focus for Today
- Grammar: Review and practice the first declension noun endings (-a, -ae, -am, -arum, -is, -as).
- Chant: Recite the first declension noun endings to reinforce memory.
- Vocabulary: 
  - puella (girl)
  - aqua (water)
  - terra (earth)
  - rosa (rose)
  - femina (woman)
  - via (road)

## Virtue & Faith Connection
In learning Latin, we cultivate the virtue of "disciplina" (discipline), which helps us grow in our understanding and appreciation of language. The faith phrase "Deus caritas est" (God is love) reminds us that our studies are part of a larger journey of learning and love.

## Teacher Notes
Encourage students to chant the declension endings aloud to aid memorization. Remind them to pay attention to pronunciation, particularly the long "a" sound in the nominative and accusative singular forms. Allow time for students to practice translating simple sentences using first declension nouns.