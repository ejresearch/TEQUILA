```markdown
---
week: 1
day: 2
title: "Week 1 Day 2"
time_window_minutes: 20
tone: "warm-positive-brief"
audience: "Grade 3 (Grammar Stage, U.S.)"
license: "CC BY 4.0"
provenance:
  generator: "Steel"
  prompt_id: "prompt_for_guidelines"
  version: "1.0.0"
  generated_at: "2023-10-10T14:00:00Z"
---

# Week 1 Day 2: Week 1 Day 2

## Objectives & Success Criteria
### Objectives
- Students will practice basic Latin greetings.
- Students will use 'Pax vobiscum' in context.
- Students will demonstrate understanding of respect in greetings.

### Success Criteria
- Students correctly use 'salve' and 'vale'.
- Students pronounce 'Pax vobiscum' accurately.
- Students demonstrate respect in greetings.

## Materials & Setup
- Chant chart (from WeekSpec)
- Flashcards (salve, vale, pax)
- Parsing worksheet (cases, numbers)
- Visual aids for vocabulary

## Minute-by-Minute Flow

### Phase 1: Greeting & Spiral Review (5 min)
**Sparky says:**
"Salvē, discipuli! Today we'll practice **Respect** as we greet each other in Latin."

**Activity:**
- Show flashcards: "salve", "vale", "pax"
- Ask: "What does 'salve' mean?" (Hint: It's how we say hello!)
- Recycle grammar structure: "What do we say when we leave?"

**Check for Understanding:**
- "What is the Latin word for hello?"

---

### Phase 2: Chant Introduction/Practice (5–7 min)
**Sparky says:**
"Great job with 'salve'! Let's chant it once slowly, then once with rhythm."

**Activity:**
- Display chant chart
- Model chant: "Salve, discipuli! Vale, amici! Pax vobiscum."
- Students echo
- Point to endings as they chant

**Check for Understanding:**
- "How do you say goodbye in Latin?"

---

### Phase 3: Grammar Instruction (8–10 min)
**Focus:** Practice pronunciation of 'salve' and 'vale'.

**Sparky says:**
"Remember, 'salve' is for hello and 'vale' is for goodbye. Let's practice!"

**Activity:**
- Introduce greeting structure using examples: "Salve, amice!" and "Vale, discipule!"
- Parse together: "Salve" (hello), "Vale" (goodbye)
- Highlight common misconceptions:
  - Pattern: Mixing 'salve' and 'vale'.
  - Correction cue: "Remember, 'salve' is for hello and 'vale' is for goodbye."

**Check for Understanding:**
- "What does 'Pax vobiscum' mean?"

---

### Phase 4: Guided Practice (5–7 min)
**Sparky says:**
"Try saying 'salve' with a smile!"

**Activity:**
- Present practice sentences: "Salve, amica!", "Vale, amicus!"
- Students practice in pairs
- Differentiation:
  - **Support:** Pair with a buddy for practice.
  - **Extension:** Create a short dialogue using greetings.

**Check for Understanding:**
- "Who can use 'salve' in a sentence?"

---

### Phase 5: Closure & Virtue Tie-In (2–3 min)
**Sparky says:**
"Show respect by greeting each other warmly in Latin."

**Faith Integration:**
"Use 'Pax vobiscum' as a peaceful closure to our class."

**Activity:**
- Review objectives
- Students self-assess against success criteria
- Close with faith phrase: "Pax vobiscum."

---

## Coaching Notes
### Common Misconceptions
- **Pattern:** Mixing 'salve' and 'vale'.
  **Correction Cue:** "Remember, 'salve' is for hello and 'vale' is for goodbye."

### Differentiation Strategies
- **Support:** Pair with a buddy for practice, Use visual aids for vocabulary.
- **Extension:** Create a short dialogue using greetings, Teach a friend outside class 'Pax vobiscum'.

### Classroom Management
- Keep transitions between activities smooth.
- Encourage quick participation.
- Maintain a positive and respectful atmosphere.

---

## Assessment Checkpoints
Embedded in flow above:
- Phase 1: "What is the Latin word for hello?"
- Phase 2: "How do you say goodbye in Latin?"
- Phase 3: "What does 'Pax vobiscum' mean?"
- Phase 4: "Who can use 'salve' in a sentence?"
- Phase 5: Self-assessment against success criteria
```