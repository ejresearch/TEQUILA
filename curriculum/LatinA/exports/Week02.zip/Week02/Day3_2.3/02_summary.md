---
week: 2
day: 3
license: 'CC BY 4.0'
validated_by: Steel
originality_attestation: true
---

# Week 0 Day 3: Introduction to First Declension Nouns

## Objective
Today, students will review and reinforce their understanding of first declension nouns in Latin, focusing on their forms and uses in sentences.

## Prior Knowledge
- Students have previously learned about the concept of declensions in Latin, which organize nouns based on their endings.
- Familiarity with basic Latin vocabulary such as "puella" (girl) and "aqua" (water) will support today's exploration of noun forms.

## Focus for Today
- Grammar: First declension noun endings and their grammatical cases (nominative, genitive, dative, accusative, ablative).
- Chant: Recitation of first declension endings to aid memorization.
- Vocabulary: puella, aqua, terra, via, silva, mensa, femina, patria

## Virtue & Faith Connection
Today's lesson encourages the virtue of diligence as students practice and memorize noun forms. The faith phrase "Deus est bonus" (God is good) can be used to create simple sentences using first declension nouns.

## Teacher Notes
Encourage students to chant the endings of the first declension aloud to reinforce pronunciation and memorization. Remind them to pay attention to vowel lengths, as they are crucial in distinguishing between cases. Allow time for questions and practice to ensure mastery of this foundational concept.