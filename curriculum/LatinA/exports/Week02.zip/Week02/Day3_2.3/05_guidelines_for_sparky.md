```markdown
---
week: 1
day: 3
title: "Week 1 Day 3"
time_window_minutes: 25
tone: "warm-positive-brief"
audience: "Grade 3 (Grammar Stage, U.S.)"
license: "CC BY 4.0"
provenance:
  generator: "Steel"
  prompt_id: "prompt_for_guidelines"
  version: "1.0.0"
  generated_at: "2023-10-10T14:00:00Z"
---

# Week 1 Day 3: Week 1 Day 3

## Objectives & Success Criteria
### Objectives
- Students will practice using Latin greetings in conversation.
- Students will demonstrate understanding of the faith phrase 'Pax vobiscum'.
- Students will connect the virtue of respect to language use.

### Success Criteria
- Students use 'salve' and 'vale' correctly in conversation.
- Students pronounce 'Pax vobiscum' accurately.
- Students connect greetings to showing respect.

## Materials & Setup
- Chant chart (from WeekSpec)
- Flashcards (vocabulary_spiral: salve, vale, pax, amicus, amica)
- Parsing worksheet (cases, numbers)
- Visual aids for vocabulary

## Minute-by-Minute Flow

### Phase 1: Greeting & Spiral Review (5 min)
**Sparky says:**
"Salvē, discipuli! Today we'll practice **Respect** as we greet each other in Latin."

**Activity:**
- Show flashcards: salve, vale, pax, amicus, amica
- Ask: "What does 'salve' mean?" (Hint: It's what you say when you meet someone.)
- Recycle grammar_spiral: "When do we use 'vale'?"

**Check for Understanding:**
- "What does 'salve' mean?"

---

### Phase 2: Chant Introduction/Practice (5–7 min)
**Sparky says:**
"Let's chant it once slowly, then once with rhythm."

**Activity:**
- Display chant chart
- Model chant: "Salve, discipuli! Vale, amici! Pax vobiscum."
- Students echo
- Point to endings as they chant

**Check for Understanding:**
- "How do you say 'goodbye' in Latin?"

---

### Phase 3: Grammar Instruction (8–10 min)
**Focus:** Practicing Latin greetings, Understanding 'Pax vobiscum', Connecting language to respect

**Sparky says:**
"Which case tells who/what does the action?"

**Activity:**
- Introduce grammar concept: Using greetings appropriately
- Show example sentence: "Salve, amica!"
- Parse together: Identify parts of speech
- Highlight common_misconceptions:
  - Pattern: Using 'vale' to greet
  - Correction cue: "Remember, 'vale' is for goodbye!"

**Check for Understanding:**
- "What is the meaning of 'Pax vobiscum'?"

---

### Phase 4: Guided Practice (5–7 min)
**Sparky says:**
"Try the sentence pattern A before B."

**Activity:**
- Present practice sentences: "Salve, amicus!", "Vale, discipula!"
- Students parse/translate with scaffolding
- Differentiation:
  - **Support:** Pair with a buddy for practice
  - **Extension:** Create a short dialogue using greetings

**Check for Understanding:**
- "Who do you greet with 'Salve, amica!'?"

---

### Phase 5: Closure & Virtue Tie-In (2–3 min)
**Sparky says:**
"Show respect by greeting each other kindly in Latin."

**Faith Integration:**
"Use 'Pax vobiscum' when wishing peace to a friend."

**Activity:**
- Review objectives
- Students self-assess against success_criteria
- Close with faith phrase: "Pax vobiscum."

---

## Coaching Notes
### Common Misconceptions
- **Pattern:** Using 'vale' to greet
  **Correction Cue:** "Remember, 'vale' is for goodbye!"

### Differentiation Strategies
- **Support:** Pair with a buddy for practice, Use visual aids for vocabulary
- **Extension:** Create a short dialogue using greetings, Teach a new greeting to the class

### Classroom Management
- Keep transitions smooth with clear cues
- Encourage participation with positive reinforcement

---

## Assessment Checkpoints
Embedded in flow above:
- Phase 1: "What does 'salve' mean?"
- Phase 2: "How do you say 'goodbye' in Latin?"
- Phase 3: "What is the meaning of 'Pax vobiscum'?"
- Phase 4: "Who do you greet with 'Salve, amica!'?"
- Phase 5: Self-assessment against success_criteria
```