---
week: 2
day: 4
license: 'CC BY 4.0'
validated_by: Steel
originality_attestation: true
---

# Week 0 Day 4: Introduction to Latin Noun Declensions

## Objective
Today, students will learn about the first declension of Latin nouns, focusing on recognizing and applying the correct endings for singular and plural forms.

## Prior Knowledge
- Students have previously learned basic Latin vocabulary such as "puella" (girl) and "aqua" (water).
- Familiarity with Latin pronunciation and simple sentence structures has been established.

## Focus for Today
- Grammar: First declension noun endings in Latin.
- Chant: Recitation of the first declension endings to reinforce memorization.
- Vocabulary: puella, aqua, terra, nauta, poeta, agricola, femina, via.

## Virtue & Faith Connection
Today's study of declensions reflects the virtue of discipline, as students practice precision in language. The faith phrase "Deus est bonus" (God is good) reminds us of the beauty and order in language.

## Teacher Notes
Encourage students to chant the declension endings aloud to aid memorization. Remind them that Latin pronunciation emphasizes clarity and accuracy, particularly with vowel sounds. Consider pacing the lesson to allow time for individual practice and reflection on the quiz results to reinforce learning.