```markdown
---
week: 1
day: 4
title: "Week 1 Day 4"
time_window_minutes: 25
tone: "warm-positive-brief"
audience: "Grade 3 (Grammar Stage, U.S.)"
license: "CC BY 4.0"
provenance:
  generator: "Steel"
  prompt_id: "prompt_for_guidelines"
  version: "1.0.0"
  generated_at: "2023-10-10T14:00:00Z"
---

# Week 1 Day 4: Week 1 Day 4

## Objectives & Success Criteria
### Objectives
- Students will practice using basic Latin greetings.
- Students will demonstrate understanding of 'Pax vobiscum'.
- Students will connect greetings to the virtue of respect.

### Success Criteria
- Students use 'salve' and 'vale' correctly.
- Students pronounce 'Pax vobiscum' accurately.
- Students connect greetings to showing respect.

## Materials & Setup
- Chant chart (from WeekSpec)
- Flashcards (salve, vale, pax)
- Parsing worksheet (cases, numbers)
- Visual aids for vocabulary

## Minute-by-Minute Flow

### Phase 1: Greeting & Spiral Review (5 min)
**Sparky says:**
"Salvē, discipuli! Today, let's show respect by greeting each other warmly in Latin!"

**Activity:**
- Show flashcards: "Salve", "Vale", "Pax"
- Ask: "What does 'salve' mean?" (Hint: It's how we say hello!)
- Recycle grammar: "What is 'vale' used for?"

**Check for Understanding:**
- "What does 'salve' mean?"

---

### Phase 2: Chant Introduction/Practice (5–7 min)
**Sparky says:**
"Great job with 'salve'! Let's chant it once slowly, then once with rhythm."

**Activity:**
- Display chant chart
- Model chant: "Salve, discipuli! Vale, amici! Pax vobiscum."
- Students echo
- Point to endings as they chant

**Check for Understanding:**
- "How do you say goodbye in Latin?"

---

### Phase 3: Grammar Instruction (8–10 min)
**Focus:** Practice Latin greetings and farewells.

**Sparky says:**
"Remember, 'vale' is for goodbye! Let's see how we use 'Pax vobiscum'."

**Activity:**
- Introduce 'Pax vobiscum' usage
- Show example sentence: "Pax vobiscum, amice."
- Parse together: "Pax" (noun, singular), "vobiscum" (with you)
- Highlight misconception: Using 'vale' for hello
  - Correction: "Remember, 'vale' means goodbye!"

**Check for Understanding:**
- "What does 'Pax vobiscum' mean?"

---

### Phase 4: Guided Practice (5–7 min)
**Sparky says:**
"Try saying 'Pax vobiscum' with a smile."

**Activity:**
- Present practice sentences: "Salve, amica!", "Vale, discipule!", "Pax vobiscum."
- Students parse/translate with scaffolding
- Differentiation:
  - **Support:** Pair students for practice dialogues
  - **Extension:** Create a short dialogue using all phrases

**Check for Understanding:**
- "Who can use 'salve' in a sentence?"

---

### Phase 5: Closure & Virtue Tie-In (2–3 min)
**Sparky says:**
"Let's show respect by greeting each other warmly in Latin!"

**Faith Integration:**
"Use 'Pax vobiscum' when wishing peace to a friend."

**Activity:**
- Review objectives
- Students self-assess against success criteria
- Close with faith phrase: "Pax vobiscum."

---

## Coaching Notes
### Common Misconceptions
- **Pattern:** Using 'vale' for hello
  **Correction Cue:** "Remember, 'vale' means goodbye!"

### Differentiation Strategies
- **Support:** Pair students for practice dialogues, Use visual aids for vocabulary, Provide pronunciation guides
- **Extension:** Create a short dialogue using all phrases, Research another Latin greeting, Teach a friend a new phrase

### Classroom Management
- Keep transitions smooth with clear cues
- Encourage participation with positive feedback
- Monitor time to ensure all activities fit

---

## Assessment Checkpoints
Embedded in flow above:
- Phase 1: "What does 'salve' mean?"
- Phase 2: "How do you say goodbye in Latin?"
- Phase 3: "What does 'Pax vobiscum' mean?"
- Phase 4: "Who can use 'salve' in a sentence?"
- Phase 5: Self-assessment against success criteria
```