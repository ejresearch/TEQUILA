### Teacher Notes

**Pronunciation Tips:**
- 'Salve' is pronounced with a soft 'v', like 'veh'.
- Emphasize the first syllable in 'discipulus'.

**Pacing Advice:**
- Spend the first two days on vocabulary introduction and practice.
- Use the chant daily to reinforce pronunciation and rhythm.

**Connections:**
- Last week, we introduced basic greetings. This week, expand on this by incorporating simple sentences.
- Next week, we will delve into more complex sentence structures, building on this foundation.