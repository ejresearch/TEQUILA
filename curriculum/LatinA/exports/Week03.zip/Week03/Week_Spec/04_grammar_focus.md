This week, we explore the first declension nouns, which are typically feminine. These nouns have specific endings that change based on their role in the sentence. The endings are: -a, -ae, -ae, -am, -ā for singular, and -ae, -arum, -is, -as, -is for plural. 

The chant for this week helps us remember these endings:

```
-a, -ae, -ae, -am, -ā
-ae, -arum, -is, -as, -is
```

Building on our understanding of Latin nouns, we will practice identifying and using these endings in sentences. This foundation will support our future learning of more complex noun forms.